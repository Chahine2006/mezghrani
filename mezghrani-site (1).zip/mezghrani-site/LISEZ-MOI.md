# Modèle de site restaurant : guide de modification

Tout se règle dans le fichier `js/config.js` (ouvrez-le avec un éditeur de texte). Les autres fichiers ne se touchent pas.

| Pour changer… | Modifiez dans js/config.js |
|---|---|
| Nom, slogan, texte d'accueil | `name`, `tagline`, `intro` |
| Logo | `logoImage` (chemin d'une image) ou `logoSvg` (dessin) |
| Couleurs | `colors` : `dark`, `light`, `accent` (le reste est calculé) |
| Polices | `fonts` (noms exacts de Google Fonts) |
| Photo d'accueil | `heroImage` |
| Photo d'un plat | `img:"images/mon-plat.jpg"` sur la ligne du plat |
| Menu, descriptions, prix | `menu` : une ligne `{n, d, p}` par plat |
| Plat « signature » | ajoutez `star:true` sur la ligne du plat |
| WhatsApp | `whatsapp` : indicatif + numéro, sans « + » ni espaces (ex. `213555000000`). Le numéro est actuellement fictif : « À REMPLACER » |
| Téléphone, adresse, horaires | `phoneDisplay`, `phoneLink`, `address`, `mapQuery`, `hours` |
| Réseaux sociaux | `instagram`, `facebook` |
| Masquer la section identité | `showIdentity: false` |

## Photos
Mettez vos images dans le dossier `images/` à côté de `index.html`, puis écrivez par exemple `"images/burger.jpg"`. Format conseillé : JPG ou WebP, 800 px de large, moins de 200 Ko.

## Mettre le site en ligne
Copiez le dossier entier (index.html, css/, js/, images/, favicon.svg) chez n'importe quel hébergeur de pages statiques (Netlify, Cloudflare Pages, GitHub Pages ou votre hébergeur habituel).

## Nouveau restaurant
Dupliquez le dossier, changez le bloc CONFIG, remplacez les images : le site est prêt.

## Structure
```
index.html      page du site
css/style.css   mise en page
js/config.js    TOUT le contenu à modifier
js/app.js       construit le site (ne pas modifier)
images/         vos photos
favicon.svg     petite icône de l'onglet
```
Pour voir le site en local : double-cliquez sur index.html.
