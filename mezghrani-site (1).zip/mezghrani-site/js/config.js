/* ==========================================================================
   MODIFIEZ UNIQUEMENT CE BLOC. Le reste du fichier construit le site tout seul.
   ========================================================================== */
const CONFIG = {

  // ---- 1. Le restaurant ----
  name: "MEZGHRANI",
  tagline: "Le fast-food, version haute couture.",
  intro: "Burgers gourmets, tacos généreux et frites dorées à la perfection. Des produits choisis, une cuisine minutieuse, un service rapide.",
  metaDescription: "MEZGHRANI, fast-food chic : burgers gourmets, tacos et frites dorées. Commandez en ligne.",
  footerNote: "Viandes halal",
  currency: "DA",

  // ---- 2. Logo ----
  // Option A : une image (mettez le chemin ou l'adresse, ex. "images/logo.png"). Laissez "" pour utiliser l'option B.
  logoImage: "",
  // Option B : un dessin SVG (formes dessinées dans un carré de 100 x 100, utilisez currentColor pour la couleur)
  logoSvg: '<g fill="none" stroke="currentColor" stroke-width="3"><rect x="20" y="20" width="60" height="60"/><rect x="20" y="20" width="60" height="60" transform="rotate(45 50 50)"/><circle cx="50" cy="50" r="11" fill="currentColor" stroke="none"/></g>',

  // ---- 3. Couleurs (le reste de la palette en est déduit automatiquement) ----
  colors: {
    dark:   "#0C0B09",   // fond principal
    light:  "#F3EAD8",   // texte et sections claires
    accent: "#C9A24B"    // boutons, titres, détails
  },
  colorNames: { dark: "Noir", light: "Crème", accent: "Or" },   // noms affichés dans la section identité

  // ---- 4. Polices (noms exacts de Google Fonts) ----
  fonts: { display: "Bodoni Moda", body: "Jost" },

  // ---- 5. Photos (chemin ou adresse ; laissez "" pour ne rien afficher) ----
  heroImage: "",                      // grande photo derrière le titre d'accueil
  // Les photos des plats se règlent plus bas, avec img:"..." sur chaque plat.

  // ---- 6. Contact ----
  whatsapp: "213000000000",           // À REMPLACER : indicatif pays + numéro, sans + ni espaces (numéro fictif)
  whatsappDisplay: "À REMPLACER",     // texte affiché à la place du numéro ; mettez "" une fois le vrai numéro saisi
  phoneDisplay: "À REMPLACER",           // numéro affiché (ex. "0555 00 00 00")
  phoneLink: "",                      // numéro pour l'appel (avec +). Laissez "" tant que le numéro n'est pas défini
  address: "Hydra, Alger",
  mapQuery: "MEZGHRANI Hydra Alger",  // texte cherché dans Google Maps
  hours: ["Tous les jours, 11h00 – 00h00", "Vendredi : 13h00 – 00h00"],
  orderNote: "Sur place, à emporter ou en livraison.",
  instagram: "",                      // adresse complète ou ""
  facebook: "",

  // ---- 7. Sections ----
  showIdentity: true,                 // false pour masquer la section « Notre identité »
  identityTitle: "Notre identité",
  identityText: "Une étoile à huit branches, héritée de la géométrie des arts algériens, posée comme un sceau. Noir profond, crème chaud et or : l’élégance d’une maison, la vitesse d’un comptoir.",
  featured: ["burgers", "tacos", "frites"],   // les catégories mises en avant sous l'accueil
  menuTitle: "La carte",
  menuIntro: "Touchez + pour composer votre commande, puis envoyez-la par WhatsApp.",
  orderMessage: "Bonjour {name}, je souhaite commander :",   // début du message WhatsApp

  // ---- 8. Le menu ----
  // Pour ajouter un plat : copiez une ligne {n:..., d:..., p:...}. Pour supprimer : effacez la ligne.
  // star:true = badge « signature ». p = prix en nombre, sans espace ni devise.
  menu: [
    {id:"burgers", title:"Burgers", note:"Pain brioché toasté, viande hachée chaque jour, sauces maison.",
      items:[
        {n:"Le Mezghrani", d:"Double steak, cheddar affiné, oignons confits, sauce maison.", p:1100, star:true, img:""},
        {n:"Truffé", d:"Steak, mozzarella, crème de champignons à la truffe.", p:1250, img:""},
        {n:"Smash classique", d:"Deux steaks écrasés, cheddar, cornichons, sauce burger.", p:750, img:""},
        {n:"Poulet croustillant", d:"Filet pané, salade croquante, sauce miel-moutarde.", p:700, img:""},
        {n:"Végétarien", d:"Galette de pois chiches, légumes grillés, houmous.", p:650, img:""},
      ]},
    {id:"tacos", title:"Tacos", note:"Galette moelleuse, grillée à la plancha, sauce fromagère à cœur.",
      items:[
        {n:"Tacos Royal", d:"Poulet mariné, frites, sauce fromagère, galette grillée.", p:650, star:true, img:""},
        {n:"Tacos Viande hachée", d:"Bœuf épicé, cheddar, frites, sauce algérienne.", p:700, img:""},
        {n:"Tacos Mixte", d:"Poulet et viande hachée, double fromage.", p:800, img:""},
        {n:"Tacos Merguez", d:"Merguez grillées, poivrons, harissa douce.", p:750, img:""},
      ]},
    {id:"frites", title:"Frites", note:"Pommes de terre fraîches, double cuisson, sel fin.",
      items:[
        {n:"Frites maison", d:"Portion généreuse, sel fin.", p:250, img:""},
        {n:"Frites fromagères", d:"Sauce cheddar fondue, oignons frits.", p:450, star:true, img:""},
        {n:"Frites parmesan", d:"Parmesan râpé, persil, huile à l’ail.", p:400, img:""},
        {n:"Frites épicées", d:"Paprika fumé et harissa en poudre.", p:300, img:""},
      ]},
    {id:"poutines", title:"Poutines", note:"Frites croustillantes, fromage en grains, sauce onctueuse.",
      items:[
        {n:"Poutine classique", d:"Frites, fromage en grains, sauce brune.", p:550, img:""},
        {n:"Poutine poulet", d:"Poulet émincé, fromage en grains, sauce brune.", p:700, img:""},
        {n:"Poutine viande hachée", d:"Bœuf épicé, cheddar fondu, oignons frits.", p:750, img:""},
        {n:"Poutine Mezghrani", d:"Poulet croustillant, cheddar, oignons frits, sauce maison.", p:850, star:true, img:""},
      ]},
    {id:"pizzas", title:"Pizzas", note:"Pâte pétrie chaque jour, cuite au four, généreusement garnie.",
      items:[
        {n:"Margherita", d:"Sauce tomate, mozzarella, basilic.", p:600, img:""},
        {n:"Reine", d:"Jambon de dinde, champignons, mozzarella.", p:800, img:""},
        {n:"Quatre fromages", d:"Mozzarella, cheddar, emmental, fromage bleu.", p:900, img:""},
        {n:"Poulet", d:"Poulet mariné, poivrons, oignons, olives.", p:850, img:""},
        {n:"Pizza Mezghrani", d:"Viande hachée, merguez, poivrons, olives, mozzarella.", p:1000, star:true, img:""},
      ]},
    {id:"sandwichs", title:"Sandwichs", note:"Pain frais, garniture copieuse, sauce au choix.",
      items:[
        {n:"Sandwich poulet", d:"Poulet grillé, salade, tomate, sauce au choix.", p:450, img:""},
        {n:"Sandwich viande hachée", d:"Viande hachée, oignons, fromage, frites.", p:500, img:""},
        {n:"Sandwich merguez", d:"Merguez grillées, poivrons, harissa douce.", p:450, img:""},
        {n:"Escalope panée", d:"Escalope croustillante, salade, sauce algérienne.", p:550, img:""},
        {n:"Cordon bleu", d:"Poulet, fromage fondu, frites, salade.", p:600, img:""},
      ]},
    {id:"tunisiens", title:"Tunisiens", note:"Pain tunisien fourré, relevé à la harissa.",
      items:[
        {n:"Tunisien thon", d:"Thon, œuf, olives, harissa, frites.", p:450, star:true, img:""},
        {n:"Tunisien poulet", d:"Poulet, œuf, olives, harissa, frites.", p:500, img:""},
        {n:"Tunisien viande hachée", d:"Viande hachée, fromage, harissa, frites.", p:550, img:""},
        {n:"Tunisien mixte", d:"Thon et poulet, œuf, olives, double fromage.", p:600, img:""},
      ]},
    {id:"paninis", title:"Paninis", note:"Pressés à chaud, fromage fondant.",
      items:[
        {n:"Panini poulet", d:"Poulet, fromage fondu, sauce blanche.", p:500, img:""},
        {n:"Panini thon", d:"Thon, olives, fromage, tomate.", p:450, img:""},
        {n:"Panini viande hachée", d:"Viande hachée, oignons, mozzarella.", p:550, img:""},
        {n:"Panini trois fromages", d:"Mozzarella, cheddar, emmental.", p:450, img:""},
        {n:"Panini dinde fumée", d:"Dinde fumée, fromage, champignons.", p:500, img:""},
      ]},
    {id:"plats", title:"Plats", note:"Des assiettes complètes, servies avec frites ou riz et salade.",
      items:[
        {n:"Escalope et frites", d:"Escalope panée, frites maison, salade.", p:900, img:""},
        {n:"Demi-poulet rôti", d:"Poulet mariné, frites, salade.", p:1000, img:""},
        {n:"Brochettes de viande", d:"Quatre brochettes, riz, salade méchouia.", p:1200, img:""},
        {n:"Pâtes crémeuses au poulet", d:"Sauce à la crème, poulet, champignons.", p:800, img:""},
        {n:"Assiette mixte", d:"Poulet, merguez, viande hachée, frites et riz.", p:1300, star:true, img:""},
      ]},
  ]
};
