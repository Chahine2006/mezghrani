/* Construit le site à partir de js/config.js. Normalement, rien à modifier ici. */
const C=CONFIG,$=s=>document.querySelector(s);
const fmt=n=>n.toLocaleString('fr-FR').replace(/[\u202f\u00a0]/g,' ');
const r=document.documentElement.style;
r.setProperty('--black',C.colors.dark);r.setProperty('--cream',C.colors.light);r.setProperty('--gold',C.colors.accent);
r.setProperty('--serif',`'${C.fonts.display}','Didot','Times New Roman',serif`);
r.setProperty('--sans',`'${C.fonts.body}','Helvetica Neue',Arial,sans-serif`);
const fl=document.createElement('link');fl.rel='stylesheet';
fl.href='https://fonts.googleapis.com/css2?family='+[C.fonts.display,C.fonts.body].map(f=>f.replace(/ /g,'+')+':wght@400;500;600;700').join('&family=')+'&display=swap';
document.head.appendChild(fl);
document.title=C.name+' – '+C.tagline;
document.querySelector('meta[name=description]').content=C.metaDescription;
document.querySelector('meta[name=theme-color]').content=C.colors.dark;
const logo=(cls,color)=>C.logoImage?`<img class="logo-img ${cls}" src="${C.logoImage}" alt="Logo ${C.name}">`:`<svg class="star ${cls}" viewBox="0 0 100 100" style="color:${color||'var(--gold)'}" aria-hidden="true">${C.logoSvg}</svg>`;
const lum=h=>{const n=parseInt(h.replace('#',''),16);return (.299*(n>>16)+.587*((n>>8)&255)+.114*(n&255))/255};
const cat=id=>C.menu.find(c=>c.id===id);
const feat=C.featured.map(cat).filter(Boolean);

$('#brand').innerHTML=logo('')+C.name;$('#brand').setAttribute('aria-label',C.name+', accueil');
$('#nav').innerHTML=feat.map(c=>`<a href="#${c.id}">${c.title}</a>`).join('')+(C.showIdentity?'<a href="#identite">Identité</a>':'')+'<a class="btn" href="#contact">Venir nous voir</a>';
const hero=$('#hero');if(C.heroImage){hero.classList.add('has-img');hero.style.setProperty('--hero',`url("${C.heroImage}")`)}
$('#hero .wrap').innerHTML=logo('')+`<h1>${C.name}</h1><div class="sub">${C.tagline}</div><p>${C.intro}</p><div class="cta"><a class="btn" href="#menu">Découvrir la carte</a><a class="btn line" href="#contact">Horaires et adresse</a></div>`;
$('#trio').innerHTML=feat.map(c=>`<a href="#${c.id}">${c.title}</a>`).join('');$('#trio').style.gridTemplateColumns=`repeat(${feat.length||1},1fr)`;
$('#mh').textContent=C.menuTitle;$('#mi').textContent=`Prix en ${C.currency==='DA'?'dinars algériens (DA)':C.currency}. `+C.menuIntro;
$('#chips').innerHTML=C.menu.map(c=>`<a href="#${c.id}">${c.title}</a>`).join('');
$('#cats').innerHTML=C.menu.map(c=>`<div class="cat" id="${c.id}"><div><h2>${c.title}</h2>${c.note?`<p class="note">${c.note}</p>`:''}</div><div class="list">`+c.items.map((it,i)=>
 `<div class="row${it.img?' pic':''}">${it.img?`<img class="th" src="${it.img}" alt="${it.n}" loading="lazy">`:''}<h3>${it.n}${it.star?'<span class="sig">signature</span>':''}</h3><span class="pr">${fmt(it.p)} ${C.currency}</span><p>${it.d||''}</p><div class="ctl" data-k="${c.id}:${i}"><button class="mn" type="button" aria-label="Retirer ${it.n}" data-d="-1">−</button><span class="q"></span><button type="button" aria-label="Ajouter ${it.n}" data-d="1">+</button></div></div>`).join('')+'</div></div>').join('');

const idn=$('#identite');
if(C.showIdentity){
 const sw=Object.keys(C.colors).map(k=>`<span style="background:${C.colors[k]};color:${lum(C.colors[k])<.5?'#fff':'#111'}">${(C.colorNames||{})[k]||k}<br>${C.colors[k]}</span>`).join('');
 idn.innerHTML=`<div class="wrap"><h2>${C.identityTitle}</h2><p class="lead">${C.identityText}</p><div class="idgrid"><div class="box dark">${logo('')}<b>${C.name}</b><small style="color:var(--gold-lt)">${C.tagline}</small></div><div class="box"><div><h3>Couleurs</h3></div><div class="sw">${sw}</div><div><h3 style="font-weight:700">${C.fonts.display}</h3><small>Titres et prix.</small></div><div><h3 style="font-family:var(--sans);font-weight:500;font-size:1.6rem">${C.fonts.body}</h3><small>Texte courant, net et lisible sur tous les écrans.</small></div></div></div></div>`;
}else idn.remove();
const wa=`https://api.whatsapp.com/send?phone=${C.whatsapp}`;
$('#contact').innerHTML=`<div class="wrap"><h2 class="mh">Nous trouver</h2></div><div class="wrap info"><div><h3>Adresse</h3><p>${C.address}<br><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(C.mapQuery)}" target="_blank" rel="noopener">Voir l’itinéraire</a></p></div><div><h3>Horaires</h3><p>${C.hours.join('<br>')}</p></div><div><h3>Commander</h3><p>${C.orderNote}<br>${C.phoneLink?`<a href="tel:${C.phoneLink}">${C.phoneDisplay}</a>`:C.phoneDisplay}<br>WhatsApp : ${C.whatsappDisplay||`<a href="${wa}" target="_blank" rel="noopener">+${C.whatsapp}</a>`}</p></div></div>`;
$('#foot').innerHTML=`<span>© ${new Date().getFullYear()} ${C.name}. Tous droits réservés.</span><span>${[C.footerNote,C.instagram&&`<a href="${C.instagram}" target="_blank" rel="noopener">Instagram</a>`,C.facebook&&`<a href="${C.facebook}" target="_blank" rel="noopener">Facebook</a>`].filter(Boolean).join(' · ')}</span>`;

/* Panier et commande WhatsApp */
const cart={},bar=$('#bar'),sum=$('#sum'),sendA=$('#send');let orderTxt='';
function draw(){
 let q=0,t=0,lines=[];
 for(const k in cart){const [id,i]=k.split(':'),it=cat(id).items[i];q+=cart[k];t+=cart[k]*it.p;lines.push(cart[k]+' × '+it.n)}
 sum.textContent=q+(q>1?' articles':' article')+' – '+fmt(t)+' '+C.currency;
 bar.classList.toggle('on',q>0);
 document.querySelectorAll('.ctl').forEach(c=>{const n=cart[c.dataset.k]||0;c.classList.toggle('has',n>0);c.querySelector('.q').textContent=n});
 orderTxt=C.orderMessage.replace('{name}',C.name)+'\n'+lines.join('\n')+'\nTotal : '+fmt(t)+' '+C.currency;
 sendA.href=wa+'&text='+encodeURIComponent(orderTxt);
}
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-d]');if(!b)return;
 const k=b.closest('.ctl').dataset.k;cart[k]=Math.max(0,(cart[k]||0)+Number(b.dataset.d));
 if(!cart[k])delete cart[k];draw();
});
$('#clr').onclick=()=>{for(const k in cart)delete cart[k];draw()};
$('#copy').onclick=async e=>{
 const b=e.currentTarget;
 try{await navigator.clipboard.writeText(orderTxt)}catch(_){const a=document.createElement('textarea');a.value=orderTxt;document.body.appendChild(a);a.select();try{document.execCommand('copy')}catch(_){}a.remove()}
 b.textContent='Copié ✓';setTimeout(()=>b.textContent='Copier',1800);
};
